INSERT INTO aprendices VALUES
(1001, 'Ana', 'Gomez', '3001234567', 'ana@gmail.com'),
(1002, 'Luis', 'Martinez', '3019876543', 'luis@hotmail.com'),
(1003, 'Carlos', 'Rodriguez', '3024567890', 'carlos@gmail.com'),
(1004, 'Maria', 'Lopez', '3035556677', 'maria@yahoo.com'),
(1005, 'Andres', 'Garcia', '3048889999', 'andres@gmail.com');

INSERT INTO modalidades (Tipo_modalidad) VALUES
('Presencial'),
('Virtual'),
('Mixta');

INSERT INTO programas (Nombre_programa, Duracion_programa, Id_modalidad) VALUES
('Tecnólogo en ADSO', '27 meses', 1),
('Técnico en Sistemas', '12 meses', 2),
('Tecnólogo en Contabilidad', '24 meses', 3),
('Técnico en Cocina', '18 meses', 1),
('Tecnólogo en Software', '30 meses', 2);

INSERT INTO inscripciones 
(Documento_aprendiz, Id_programa, Ficha_inscripcion, Fecha_inicio, Fecha_fin, Estado_inscripcion) VALUES
(1001, 1, 'ADSO-2501', '2024-01-15', '2026-04-15', 'Activa'),
(1002, 2, 'SIS-2402', '2023-02-01', '2024-02-01', 'Finalizada'),
(1003, 3, 'CON-2503', '2024-03-10', '2026-03-10', 'Activa'),
(1004, 4, 'COC-2404', '2023-04-05', '2024-10-05', 'Cancelada'),
(1005, 5, 'SOF-2505', '2024-05-20', '2026-11-20', 'Activa');

INSERT INTO instructores VALUES
(2001, 'Pedro', 'Gonzalez', '3101112233', 'pedro@sena.edu.co'),
(2002, 'Laura', 'Ramirez', '3112223344', 'laura@sena.edu.co'),
(2003, 'Jorge', 'Castro', '3123334455', 'jorge@sena.edu.co'),
(2004, 'Diana', 'Morales', '3134445566', 'diana@sena.edu.co'),
(2005, 'Sergio', 'Gomez', '3145556677', 'sergio@sena.edu.co');

INSERT INTO instructores_programas 
(Documento_instructor, Id_programa, Fecha_asignacion) VALUES
(2001, 1, '2024-01-10'),
(2002, 2, '2023-01-15'),
(2003, 3, '2024-02-20'),
(2004, 4, '2023-03-05'),
(2005, 5, '2024-04-12');

INSERT INTO competencias 
(Nombre_competencia, Duracion_competencia, Descripcion_competencia) VALUES
('Programación en Java', '6 meses', 'Desarrollo de software en Java'),
('Bases de Datos', '5 meses', 'Diseño y gestión de bases de datos'),
('Contabilidad Básica', '4 meses', 'Fundamentos contables'),
('Cocina Internacional', '6 meses', 'Preparación de platos del mundo'),
('Desarrollo Web', '7 meses', 'Creación de aplicaciones web');

INSERT INTO competencias_programa 
(Id_competencia, Id_programa) VALUES
(1, 1),
(2, 1),
(3, 3),
(4, 4),
(5, 5);

INSERT INTO competencias_instructor 
(Id_competencia, Documento_instructor, Fecha_certificacion) VALUES
(1, 2001, '2022-06-10'),
(2, 2002, '2021-08-15'),
(3, 2003, '2020-05-20'),
(4, 2004, '2019-11-30'),
(5, 2005, '2023-01-25');


