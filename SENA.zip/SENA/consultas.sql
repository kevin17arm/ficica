#Aprendices cuyo nombre empieza por “A” y correo contiene “gmail”
SELECT *
FROM aprendices
WHERE Nombre_aprendiz LIKE 'A%'
AND Correo_aprendiz LIKE '%gmail%';


   
   #Competencias cuyo nombre contenga “programación” o “software”
   SELECT *
FROM competencias
WHERE Nombre_competencia LIKE '%programación%'
OR Nombre_competencia LIKE '%software%';
   
   #Inscripciones activas o finalizadas con ficha que contenga “25”
   SELECT *
FROM inscripciones
WHERE (Estado_inscripcion = 'Activa'
       OR Estado_inscripcion = 'Finalizada')
AND Ficha_inscripcion LIKE '%25%';

#Instructores con apellido que empiece por “G” y teléfono que contenga “3”
SELECT *
FROM instructores
WHERE Apellido_instructor LIKE 'G%'
AND Telefono_instructor LIKE '%3%';

#Programas cuya duración contenga “mes” o “año
SELECT *
FROM programas
WHERE Duracion_programa LIKE '%mes%'
OR Duracion_programa LIKE '%año%';
