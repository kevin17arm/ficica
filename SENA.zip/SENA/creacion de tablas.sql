create database if not exists SENA;   
use SENA;

CREATE TABLE aprendices (
    Documento_aprendiz INT(11) PRIMARY KEY,
    Nombre_aprendiz VARCHAR(50),
    Apellido_apendiz VARCHAR(50),
    Telefono_apendiz VARCHAR(20),
    Correo_aprendiz VARCHAR(100)
);

CREATE TABLE modalidades (
    Id_modalidad INT(11) PRIMARY KEY AUTO_INCREMENT,
    Tipo_modalidad ENUM('Presencial','Virtual','Mixta')
);


CREATE TABLE programas (
    Id_programa INT(11) PRIMARY KEY AUTO_INCREMENT,
    Nombre_programa VARCHAR(100),
    Duracion_programa VARCHAR(50),
    Id_modalidad INT(11),
    FOREIGN KEY (Id_modalidad) REFERENCES modalidades(Id_modalidad)
);


CREATE TABLE inscripciones (
    Id_inscripcion INT(11) PRIMARY KEY AUTO_INCREMENT,
    Documento_aprendiz INT(11),
    Id_programa INT(11),
    Ficha_inscripcion VARCHAR(30),
    Fecha_inicio DATE,
    Fecha_fin DATE,
    Estado_inscripcion ENUM('Activa','Finalizada','Cancelada'),
    FOREIGN KEY (Documento_aprendiz) REFERENCES aprendices(Documento_aprendiz),
    FOREIGN KEY (Id_programa) REFERENCES programas(Id_programa)
);


CREATE TABLE instructores (
    Documento_instructor INT(11) PRIMARY KEY,
    Nombre_instructor VARCHAR(50),
    Apellido_instructor VARCHAR(50),
    Telefono_instructor VARCHAR(20),
    Correo_instructor VARCHAR(100)
);


CREATE TABLE instructores_programas (
    Id_instructor_programa INT(11) PRIMARY KEY AUTO_INCREMENT,
    Documento_instructor INT(11),
    Id_programa INT(11),
    Fecha_asignacion DATE,
    FOREIGN KEY (Documento_instructor) REFERENCES instructores(Documento_instructor),
    FOREIGN KEY (Id_programa) REFERENCES programas(Id_programa)
);


CREATE TABLE competencias (
    Id_competencia INT(11) PRIMARY KEY AUTO_INCREMENT,
    Nombre_competencia VARCHAR(100),
    Duracion_competencia VARCHAR(50),
    Descripcion_competencia TEXT
);


CREATE TABLE competencias_programa (
    Id_competencia_programa INT(11) PRIMARY KEY AUTO_INCREMENT,
    Id_competencia INT(11),
    Id_programa INT(11),
    FOREIGN KEY (Id_competencia) REFERENCES competencias(Id_competencia),
    FOREIGN KEY (Id_programa) REFERENCES programas(Id_programa)
);


CREATE TABLE competencias_instructor (
    Id_competencia_instructor INT(11) PRIMARY KEY AUTO_INCREMENT,
    Id_competencia INT(11),
    Documento_instructor INT(11),
    Fecha_certificacion DATE,
    FOREIGN KEY (Id_competencia) REFERENCES competencias(Id_competencia),
    FOREIGN KEY (Documento_instructor) REFERENCES instructores(Documento_instructor)
);